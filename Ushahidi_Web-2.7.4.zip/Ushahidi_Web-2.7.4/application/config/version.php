<?php defined('SYSPATH') or die('No direct script access.');
/**
 * The Ushahidi Engine version
 * Make sure to update the ushahidi_version in the settings table too!
 */
$config['ushahidi_version'] = "2.7.4";

/**
 * The Ushahidi Engine DB revision number
 * Increments when changes are made to the Ushahidi DB schema.
 */
$config['ushahidi_db_version'] = "117";
