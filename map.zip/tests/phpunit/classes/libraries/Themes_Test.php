<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Themes library Unit Test
 *
 * @author 		Ushahidi Team
 * @package 	Ushahidi
 * @category 	Unit Tests
 * @copyright 	(c) 2008-2011 Ushahidi Inc <http://www.ushahidi.com>
 * @license 	For license information, see License.txt
 */
class Themes_Test extends PHPUnit_Framework_TestCase {
	
	public function setUp()
	{
		
	}
	
	public function tearDown()
	{
		
	}
	
	public function testSomething()
	{
	}
	
}
	