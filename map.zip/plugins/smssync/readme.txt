=== About ===
name: SMSSync
website: http://www.ushahidi.com
description: Receive text messages from the SMSSync SMS Gateway App for Android
version: 0.8
requires: 2.0
tested up to: 2.0
author: Ushahidi Team
author website: http://www.ushahidi.com

== Description ==
Receive text messages from the SMSSync SMS Gateway App for Android

== Installation ==
1. Copy the entire /smssync/ directory into your /plugins/ directory.
2. Activate the plugin.
3. Click on the [settings] to set the 'secret'

== Changelog ==
0.8
* Added sendsms task -- allows you to use sms gateway as sender
* Other bugfixes