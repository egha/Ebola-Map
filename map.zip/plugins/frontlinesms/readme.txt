=== About ===
name: FrontlineSMS
website: http://www.frontlinesms.com
description: Receive Messages from a FrontlineSMS Installations
version: 0.5
requires: 2.0
tested up to: 2.0
author: David Kobia
author website: http://www.dkfactor.com

== Description ==
Receive Messages from a FrontlineSMS Installations.

== Installation ==
1. Copy the entire /frontlinesms/ directory into your /plugins/ directory.
2. Activate the plugin.
3. Click on the [settings] link to get your FrontlineSMS URL

== Changelog ==