=== About ===
name: Clickatell
website: http://www.ushahidi.com
description: Send and Receive Text Messages Using Clickatell
version: 0.5
requires: 2.0
tested up to: 2.0
author: David Kobia
author website: http://www.dkfactor.com

== Description ==
Send and Receive Text Messages Using Clickatell.

== Installation ==
1. Copy the entire /clickatell/ directory into your /plugins/ directory.
2. Activate the plugin.
3. Click on the [settings] link to add your clickatell information

== Changelog ==