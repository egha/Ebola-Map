=== About ===
name: Sharing
website: http://www.ushahidi.com
description: Share reports among deployments
version: 0.1
requires: 2.1
tested up to: 2.1
author: Ushahidi Team
author website: http://www.ushahidi.com

== Description ==
Share reports among deployments

== Installation ==
1. Copy the entire /sharing/ directory into your /plugins/ directory.
2. Activate the plugin.

