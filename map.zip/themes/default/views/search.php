<div id="content">
	<div class="content-bg">
		<!-- start search block -->
		<div class="big-block">
			<h1>Search Results</h1>
			<div class="search_block">
				<?php echo $search_info; ?>
				<?php echo $search_results; ?>
			</div>
		</div>
		<!-- end search block -->
	</div>
</div>