<!-- map -->
<div class="map <?php if (Kohana::config('settings.enable_timeline')) echo 'timeline-enabled'; ?>" id="map"></div>
<div style="clear:both;"></div>
<div id="mapStatus">
	<div id="mapScale"></div>
	<div id="mapMousePosition"></div>
	<div id="mapProjection"></div>
	<div id="mapOutput"></div>
</div>
<div style="clear:both;"></div>
<!-- / map -->