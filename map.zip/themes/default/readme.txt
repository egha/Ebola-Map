Theme Name: Default
Description:
Version: 1.0
Author: Ushahidi
Author Email: team@ushahidi.com
Demo: http://www.ushahidi.com
CSS: base,accordion,slider,style
JS: 
