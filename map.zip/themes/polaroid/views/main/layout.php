<!-- content -->
<div class="content-container">

	<!-- content blocks -->
			<?php blocks::render(); ?>
	<!-- /content blocks -->

</div>
<!-- content -->
