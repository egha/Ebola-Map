Theme Name: Polaroid
Description: NOTE: Polaroid requires you to change additional settings -> http://goo.gl/Mw3o9
Version: 1.1
Author: Caleb Bell
Author Email: caleb@ushahidi.com
JS: initialize,_jquery.colorbox-min,_jquery.isotope.min

===INSTALLATION===
1. Activate the theme
2. Go to the Manage -> Blocks section in the admin panel and hide all blocks except for
the Polaroid block. (http://goo.gl/kmyH4)


===CHANGELOG===

Polaroid v1.1 09-26-2011
---------------------------------
* merged Polaroid plugin files into the theme folder since we now have the ability
to access hooks within the theme system.
* update screenshot

Polaroid v1, 09-22-2011
---------------------------------
* version 1 released
