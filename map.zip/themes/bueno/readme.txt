Theme Name: Bueno
Description: Repurposing the Bueno Wordpress theme into an Ushahidi Theme.
Demo: http://www.woothemes.com/2009/11/bueno/
Version: 1.0
Author: Caleb Bell
Author Email: caleb@ushahidi.com

::Changing the Color Scheme::
By default, the color scheme is a dark pink. However, there are several
pre-configured color schemes located in the "color-options" folder. To use them, just move or copy the desired css file to the same directory the "_default.css" file is in your site will automatically update to that color.