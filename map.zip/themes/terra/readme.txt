Theme Name: Terra
Description: Some dark blues and browns
Demo: http://beta1-1.ushahididev.com/
Version: 1.0
Author: David Kobia
Author Email: david@ushahidi.com